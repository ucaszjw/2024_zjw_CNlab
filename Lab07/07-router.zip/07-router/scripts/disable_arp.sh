#!/bin/bash

arptables -A FORWARD -j DROP
arptables -A OUTPUT -j DROP

#!/bin/bash

arptables -A FORWARD -j DROP
arptables -A OUTPUT -j DROP
